#!/usr/bin/env python3
"""
HIT140 Assessment 2: IMPROVED Bat vs Rat Analysis
Investigation A: Do bats perceive rats as predators and show avoidance behavior?

Enhanced version with proper statistical analysis and professional Excel formatting
Group Work -Sydney Group 71
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.stats import chi2_contingency, ttest_ind, mannwhitneyu, pearsonr
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
import warnings
import os
warnings.filterwarnings('ignore')

# Set plotting style
plt.style.use('seaborn-v0_8')
sns.set_palette("husl")

class ImprovedBatRatAnalysis:
    def __init__(self, dataset1_path, dataset2_path):
        """Initialize the analysis with dataset paths"""
        self.dataset1_path = dataset1_path
        self.dataset2_path = dataset2_path
        self.df1 = None
        self.df2 = None
        self.results = {}
        self.output_dir = os.path.dirname(os.path.abspath(__file__))
        
        print(f"🔧 Working Directory: {self.output_dir}")
        print(f"📁 Excel file will be saved as: {os.path.join(self.output_dir, 'HIT140_Professional_Analysis_Results.xlsx')}")
        print(f"📁 Figures will be saved in: {os.path.join(self.output_dir, 'figures')}")
        
    def load_and_clean_data(self):
        """Load and clean both datasets with improved logic"""
        print("\n" + "="*60)
        print("LOADING AND CLEANING DATA")
        print("="*60)
        
        # Load Dataset 1
        print(f"\n1. Loading Dataset 1 from: {self.dataset1_path}")
        try:
            self.df1 = pd.read_csv(self.dataset1_path)
            print(f"   ✓ Dataset 1 loaded: {self.df1.shape[0]} rows, {self.df1.shape[1]} columns")
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return False
            
        # Load Dataset 2
        print(f"\n2. Loading Dataset 2 from: {self.dataset2_path}")
        try:
            self.df2 = pd.read_csv(self.dataset2_path)
            print(f"   ✓ Dataset 2 loaded: {self.df2.shape[0]} rows, {self.df2.shape[1]} columns")
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return False
        
        # Enhanced data cleaning
        self.enhanced_data_cleaning()
        
        return True
    
    def enhanced_data_cleaning(self):
        """Enhanced data cleaning with proper rat presence detection"""
        print("\n3. Enhanced Data Cleaning Process:")
        
        # Clean Dataset 1
        print("   📋 Cleaning Dataset 1...")
        original_shape = self.df1.shape
        
        # Handle missing values
        self.df1 = self.df1.replace('########', np.nan)
        
        # Convert numeric columns
        numeric_cols = ['bat_landing_to_food', 'seconds_after_rat_arrival', 'risk', 'reward', 'month', 'hours_after_sunset']
        for col in numeric_cols:
            if col in self.df1.columns:
                self.df1[col] = pd.to_numeric(self.df1[col], errors='coerce')
        
        # *** IMPROVED RAT PRESENCE DETECTION ***
        # Method 1: Use 'habit' column to identify rat presence
        if 'habit' in self.df1.columns:
            # Rats are present when habit contains 'rat'
            self.df1['rat_present'] = self.df1['habit'].str.contains('rat', na=False)
            print(f"      ✓ Rat presence detected using 'habit' column")
            
        # Method 2: Alternative using seconds_after_rat_arrival
        # If seconds_after_rat_arrival has valid values, rats were present
        if 'seconds_after_rat_arrival' in self.df1.columns:
            # Create a more nuanced rat presence indicator
            valid_timing = ~self.df1['seconds_after_rat_arrival'].isna()
            immediate_response = self.df1['seconds_after_rat_arrival'] < 30
            
            # High rat pressure: immediate response required
            self.df1['high_rat_pressure'] = valid_timing & immediate_response
            print(f"      ✓ High rat pressure indicator created")
        
        # Create vigilance categories based on landing delay
        if 'bat_landing_to_food' in self.df1.columns:
            median_delay = self.df1['bat_landing_to_food'].median()
            self.df1['high_vigilance'] = self.df1['bat_landing_to_food'] > median_delay
            print(f"      ✓ Vigilance categories created (median delay: {median_delay:.2f}s)")
        
        # Enhanced behavioral categories
        self.df1['risk_category'] = self.df1['risk'].map({0: 'Risk-Avoidance', 1: 'Risk-Taking'})
        self.df1['reward_category'] = self.df1['reward'].map({0: 'No Reward', 1: 'Reward'})
        
        # Create timing intensity categories
        if 'seconds_after_rat_arrival' in self.df1.columns:
            self.df1['timing_category'] = pd.cut(
                self.df1['seconds_after_rat_arrival'], 
                bins=[-1, 30, 120, 300, np.inf], 
                labels=['Immediate', 'Quick', 'Delayed', 'Very_Delayed']
            )
        
        print(f"      ✓ Dataset 1 final shape: {self.df1.shape}")
        
        # Clean Dataset 2
        print("   📋 Cleaning Dataset 2...")
        # Convert numeric columns
        numeric_cols2 = ['month', 'hours_after_sunset', 'bat_landing_number', 'food_availability', 'rat_minutes', 'rat_arrival_number']
        for col in numeric_cols2:
            if col in self.df2.columns:
                self.df2[col] = pd.to_numeric(self.df2[col], errors='coerce')
        
        # Enhanced rat activity indicators
        if 'rat_arrival_number' in self.df2.columns:
            self.df2['rats_active'] = self.df2['rat_arrival_number'] > 0
            self.df2['rat_activity_level'] = pd.cut(
                self.df2['rat_arrival_number'], 
                bins=[-1, 0, 1, 3, np.inf], 
                labels=['None', 'Low', 'Medium', 'High']
            )
        
        print(f"      ✓ Dataset 2 final shape: {self.df2.shape}")
        print("   ✅ Enhanced cleaning completed!")
    
    def comprehensive_descriptive_analysis(self):
        """Enhanced descriptive analysis"""
        print("\n" + "="*60)
        print("COMPREHENSIVE DESCRIPTIVE ANALYSIS")
        print("="*60)
        
        self.results['descriptive'] = {}
        
        # Rat presence analysis
        print("\n🐭 RAT PRESENCE ANALYSIS:")
        if 'rat_present' in self.df1.columns:
            rat_counts = self.df1['rat_present'].value_counts()
            rat_pct = self.df1['rat_present'].value_counts(normalize=True) * 100
            
            print(f"   • Observations with rats present: {rat_counts.get(True, 0)} ({rat_pct.get(True, 0):.1f}%)")
            print(f"   • Observations without rats: {rat_counts.get(False, 0)} ({rat_pct.get(False, 0):.1f}%)")
            
            if rat_counts.get(False, 0) > 0:
                print("   ✅ Good! We have comparison groups for statistical testing")
            else:
                print("   ⚠️  Warning: No 'rats absent' control group - using alternative analysis")
        
        # Behavioral pattern analysis
        print("\n🦇 BAT BEHAVIORAL PATTERNS:")
        
        # Risk behavior by context
        if all(col in self.df1.columns for col in ['habit', 'risk_category']):
            risk_by_context = pd.crosstab(self.df1['habit'], self.df1['risk_category'], normalize='index') * 100
            print("\n   Risk Behavior by Context (%):")
            print(risk_by_context.round(1))
            self.results['descriptive']['risk_by_context'] = risk_by_context
        
        # Vigilance analysis
        if 'high_vigilance' in self.df1.columns:
            vigilance_stats = self.df1.groupby('habit')['bat_landing_to_food'].agg(['count', 'mean', 'std', 'median'])
            print("\n   Vigilance (Landing Delay) by Context:")
            print(vigilance_stats.round(2))
            self.results['descriptive']['vigilance_by_context'] = vigilance_stats
        
        # Success rates by different factors
        print("\n🎯 SUCCESS RATE ANALYSIS:")
        if all(col in self.df1.columns for col in ['habit', 'reward']):
            success_by_context = self.df1.groupby('habit')['reward'].agg(['count', 'mean']).round(3)
            success_by_context.columns = ['Total_Attempts', 'Success_Rate']
            print("\n   Success Rates by Context:")
            print(success_by_context)
            self.results['descriptive']['success_by_context'] = success_by_context
        
        # Dataset 2 insights
        print("\n📊 OBSERVATION PERIOD PATTERNS:")
        if 'rats_active' in self.df2.columns:
            rat_activity_summary = self.df2.groupby('rats_active').agg({
                'bat_landing_number': ['count', 'mean'],
                'food_availability': 'mean'
            }).round(2)
            print("\n   Bat Activity when Rats Are Active vs Inactive:")
            print(rat_activity_summary)
            self.results['descriptive']['rat_activity_impact'] = rat_activity_summary
        
        print("\n✅ Comprehensive descriptive analysis completed!")
    
    def advanced_statistical_analysis(self):
        """Enhanced statistical analysis with multiple approaches"""
        print("\n" + "="*60)
        print("ADVANCED STATISTICAL ANALYSIS")
        print("="*60)
        
        self.results['statistical'] = {}
        
        print("\n🎯 INVESTIGATION A: Multiple Statistical Approaches")
        print("="*50)
        
        # Approach 1: Context-based analysis (rat vs non-rat situations)
        self.analyze_by_context()
        
        # Approach 2: Timing-based analysis
        self.analyze_timing_patterns()
        
        # Approach 3: Intensity-based analysis
        self.analyze_by_rat_intensity()
        
        # Approach 4: Combined dataset analysis
        self.cross_dataset_analysis()
        
        print("\n✅ Advanced statistical analysis completed!")
    
    def analyze_by_context(self):
        """Analyze behavior by different contexts (rat vs non-rat)"""
        print("\n1. 📋 CONTEXT-BASED ANALYSIS")
        print("-" * 40)
        
        if 'habit' not in self.df1.columns:
            print("   ⚠️  Context data not available")
            return
        
        # Separate rat and non-rat contexts
        rat_contexts = self.df1[self.df1['habit'].str.contains('rat', na=False)]
        non_rat_contexts = self.df1[~self.df1['habit'].str.contains('rat', na=False)]
        
        print(f"   • Rat-related contexts: {len(rat_contexts)} observations")
        print(f"   • Non-rat contexts: {len(non_rat_contexts)} observations")
        
        if len(rat_contexts) > 0 and len(non_rat_contexts) > 0:
            # Test 1: Risk-taking behavior
            print("\n   🎲 Risk-Taking Behavior Test:")
            
            # Chi-square test for risk behavior
            context_risk_crosstab = pd.crosstab(
                self.df1['habit'].str.contains('rat', na=False), 
                self.df1['risk']
            )
            
            chi2, p_val, dof, expected = chi2_contingency(context_risk_crosstab)
            cramers_v = np.sqrt(chi2 / (context_risk_crosstab.sum().sum() * (min(context_risk_crosstab.shape) - 1)))
            
            print(f"      χ² = {chi2:.4f}, p = {p_val:.4f}, Cramér's V = {cramers_v:.4f}")
            
            if p_val < 0.05:
                print("      ✅ SIGNIFICANT difference in risk-taking behavior")
            else:
                print("      ❌ No significant difference in risk-taking behavior")
            
            self.results['statistical']['risk_context_test'] = {
                'chi2': chi2, 'p_value': p_val, 'cramers_v': cramers_v,
                'significant': p_val < 0.05
            }
            
            # Test 2: Vigilance behavior
            print("\n   👁️  Vigilance Behavior Test:")
            
            rat_vigilance = rat_contexts['bat_landing_to_food'].dropna()
            non_rat_vigilance = non_rat_contexts['bat_landing_to_food'].dropna()
            
            if len(rat_vigilance) > 0 and len(non_rat_vigilance) > 0:
                # Use Mann-Whitney U test (non-parametric)
                u_stat, u_p = mannwhitneyu(rat_vigilance, non_rat_vigilance, alternative='two-sided')
                
                # Effect size
                n1, n2 = len(rat_vigilance), len(non_rat_vigilance)
                effect_size = u_stat / (n1 * n2)  # U / (n1 * n2)
                
                print(f"      Mean vigilance (rat contexts): {rat_vigilance.mean():.2f}s")
                print(f"      Mean vigilance (non-rat contexts): {non_rat_vigilance.mean():.2f}s")
                print(f"      Mann-Whitney U = {u_stat:.4f}, p = {u_p:.4f}")
                print(f"      Effect size = {effect_size:.4f}")
                
                if u_p < 0.05:
                    direction = "HIGHER" if rat_vigilance.mean() > non_rat_vigilance.mean() else "LOWER"
                    print(f"      ✅ SIGNIFICANT: {direction} vigilance in rat contexts")
                else:
                    print("      ❌ No significant difference in vigilance")
                
                self.results['statistical']['vigilance_context_test'] = {
                    'u_statistic': u_stat, 'p_value': u_p, 'effect_size': effect_size,
                    'rat_mean': rat_vigilance.mean(), 'non_rat_mean': non_rat_vigilance.mean(),
                    'significant': u_p < 0.05
                }
    
    def analyze_timing_patterns(self):
        """Analyze patterns based on timing after rat arrival"""
        print("\n2. ⏰ TIMING PATTERN ANALYSIS")
        print("-" * 40)
        
        if 'seconds_after_rat_arrival' not in self.df1.columns:
            print("   ⚠️  Timing data not available")
            return
        
        timing_data = self.df1[['seconds_after_rat_arrival', 'risk', 'reward', 'bat_landing_to_food']].dropna()
        
        if len(timing_data) == 0:
            print("   ⚠️  No valid timing data")
            return
        
        # Create timing categories
        timing_data['timing_group'] = pd.cut(
            timing_data['seconds_after_rat_arrival'],
            bins=[0, 60, 300, np.inf],
            labels=['Quick_Response', 'Moderate_Delay', 'Long_Delay']
        )
        
        # Test differences across timing groups
        print("\n   📊 Behavior by Response Timing:")
        
        timing_summary = timing_data.groupby('timing_group').agg({
            'risk': ['count', 'mean'],
            'reward': 'mean',
            'bat_landing_to_food': 'mean'
        }).round(3)
        
        print(timing_summary)
        
        # ANOVA test for vigilance across timing groups
        groups = [group['bat_landing_to_food'].values for name, group in timing_data.groupby('timing_group')]
        groups = [g for g in groups if len(g) > 0]  # Remove empty groups
        
        if len(groups) >= 2:
            f_stat, p_val = stats.f_oneway(*groups)
            print(f"\n   ANOVA Test (Vigilance across timing groups):")
            print(f"   F = {f_stat:.4f}, p = {p_val:.4f}")
            
            if p_val < 0.05:
                print("   ✅ SIGNIFICANT differences in vigilance across timing groups")
            else:
                print("   ❌ No significant differences across timing groups")
            
            self.results['statistical']['timing_anova'] = {
                'f_statistic': f_stat, 'p_value': p_val, 'significant': p_val < 0.05
            }
        
        self.results['statistical']['timing_patterns'] = timing_summary
    
    def analyze_by_rat_intensity(self):
        """Analyze behavior by rat activity intensity"""
        print("\n3. 🔥 RAT INTENSITY ANALYSIS")
        print("-" * 40)
        
        if 'timing_category' not in self.df1.columns:
            print("   ⚠️  Timing categories not available")
            return
        
        # Correlations between rat timing and bat behavior
        if 'seconds_after_rat_arrival' in self.df1.columns:
            correlations = {}
            
            timing_col = self.df1['seconds_after_rat_arrival']
            for behavioral_var in ['bat_landing_to_food', 'risk', 'reward']:
                if behavioral_var in self.df1.columns:
                    corr, p_val = pearsonr(timing_col.dropna(), self.df1[behavioral_var].dropna())
                    correlations[behavioral_var] = {'correlation': corr, 'p_value': p_val}
                    
                    significance = "✅ SIGNIFICANT" if p_val < 0.05 else "❌ Not significant"
                    print(f"   {behavioral_var} vs timing: r = {corr:.4f}, p = {p_val:.4f} ({significance})")
            
            self.results['statistical']['intensity_correlations'] = correlations
    
    def cross_dataset_analysis(self):
        """Analyze patterns across both datasets"""
        print("\n4. 🔄 CROSS-DATASET ANALYSIS")
        print("-" * 40)
        
        if 'rats_active' not in self.df2.columns:
            print("   ⚠️  Cross-dataset analysis not possible")
            return
        
        # Analyze periods with/without rat activity
        active_periods = self.df2[self.df2['rats_active'] == True]
        inactive_periods = self.df2[self.df2['rats_active'] == False]
        
        print(f"   • Periods with rat activity: {len(active_periods)}")
        print(f"   • Periods without rat activity: {len(inactive_periods)}")
        
        if len(active_periods) > 0 and len(inactive_periods) > 0:
            # Test bat landing frequency
            active_landings = active_periods['bat_landing_number'].dropna()
            inactive_landings = inactive_periods['bat_landing_number'].dropna()
            
            if len(active_landings) > 0 and len(inactive_landings) > 0:
                u_stat, p_val = mannwhitneyu(active_landings, inactive_landings, alternative='two-sided')
                
                print(f"\n   Bat Activity Comparison:")
                print(f"   • Mean landings (rat active): {active_landings.mean():.2f}")
                print(f"   • Mean landings (rat inactive): {inactive_landings.mean():.2f}")
                print(f"   • Mann-Whitney U = {u_stat:.4f}, p = {p_val:.4f}")
                
                if p_val < 0.05:
                    direction = "HIGHER" if active_landings.mean() > inactive_landings.mean() else "LOWER"
                    print(f"   ✅ SIGNIFICANT: {direction} bat activity when rats are active")
                else:
                    print("   ❌ No significant difference in bat activity levels")
                
                self.results['statistical']['cross_dataset_test'] = {
                    'u_statistic': u_stat, 'p_value': p_val,
                    'active_mean': active_landings.mean(),
                    'inactive_mean': inactive_landings.mean(),
                    'significant': p_val < 0.05
                }
    
    def create_professional_excel(self, filename='HIT140_Professional_Analysis_Results.xlsx'):
        """Create professionally formatted Excel file"""
        print("\n" + "="*60)
        print("CREATING PROFESSIONAL EXCEL FILE")
        print("="*60)
        
        full_path = os.path.join(self.output_dir, filename)
        print(f"📍 Saving to: {full_path}")
        
        # Define professional styling
        header_font = Font(name='Calibri', size=12, bold=True, color='FFFFFF')
        header_fill = PatternFill(start_color='2E75B6', end_color='2E75B6', fill_type='solid')
        header_alignment = Alignment(horizontal='center', vertical='center')
        
        subheader_font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
        subheader_fill = PatternFill(start_color='70AD47', end_color='70AD47', fill_type='solid')
        
        data_font = Font(name='Calibri', size=10)
        data_alignment = Alignment(horizontal='left', vertical='center')
        
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        try:
            with pd.ExcelWriter(full_path, engine='openpyxl') as writer:
                
                # Sheet 1: Executive Summary
                summary_data = [
                    ['HIT140 ASSESSMENT 2 - EXECUTIVE SUMMARY'],
                    [''],
                    ['Investigation A: Do bats perceive rats as predators?'],
                    ['Analysis Date:', pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')],
                    [''],
                    ['DATASET OVERVIEW'],
                    ['Dataset 1 (Bat Landings)', f'{self.df1.shape[0]} observations'],
                    ['Dataset 2 (Observation Periods)', f'{self.df2.shape[0]} observations'],
                    [''],
                    ['KEY STATISTICAL RESULTS']
                ]
                
                # Add statistical results to summary
                if 'statistical' in self.results:
                    for test_name, test_data in self.results['statistical'].items():
                        if isinstance(test_data, dict) and 'significant' in test_data:
                            status = '✅ SIGNIFICANT' if test_data['significant'] else '❌ Not Significant'
                            p_val = f"p = {test_data.get('p_value', 'N/A'):.4f}"
                            summary_data.append([test_name.replace('_', ' ').title(), f'{status} ({p_val})'])
                
                summary_data.extend([
                    [''],
                    ['CONCLUSION'],
                    ['Statistical evidence for predator perception:', self.get_overall_conclusion()],
                    [''],
                    ['Files Generated:'],
                    ['• Dataset sheets with original and cleaned data'],
                    ['• Detailed statistical test results'],
                    ['• Professional visualizations'],
                    ['• Comprehensive analysis summary']
                ])
                
                summary_df = pd.DataFrame(summary_data, columns=['Category', 'Value'])
                summary_df.to_excel(writer, sheet_name='Executive_Summary', index=False)
                
                # Apply styling to summary sheet
                ws = writer.sheets['Executive_Summary']
                self.apply_professional_styling(ws, summary_df)
                
                print("✓ Created Executive Summary sheet")
                
                # Sheet 2 & 3: Original Data
                self.df1.to_excel(writer, sheet_name='Dataset1_Original', index=False)
                ws1 = writer.sheets['Dataset1_Original']
                self.apply_data_styling(ws1, self.df1)
                
                self.df2.to_excel(writer, sheet_name='Dataset2_Original', index=False)
                ws2 = writer.sheets['Dataset2_Original']
                self.apply_data_styling(ws2, self.df2)
                
                print("✓ Created original dataset sheets with styling")
                
                # Sheet 4 & 5: Cleaned Data
                self.df1.to_excel(writer, sheet_name='Dataset1_Enhanced', index=False)
                ws3 = writer.sheets['Dataset1_Enhanced']
                self.apply_data_styling(ws3, self.df1)
                
                self.df2.to_excel(writer, sheet_name='Dataset2_Enhanced', index=False)
                ws4 = writer.sheets['Dataset2_Enhanced']
                self.apply_data_styling(ws4, self.df2)
                
                print("✓ Created enhanced dataset sheets with styling")
                
                # Sheet 6: Statistical Results
                if 'statistical' in self.results:
                    stats_data = []
                    for test_name, test_data in self.results['statistical'].items():
                        stats_data.append([f'=== {test_name.upper().replace("_", " ")} ===', ''])
                        if isinstance(test_data, dict):
                            for key, value in test_data.items():
                                if not isinstance(value, (pd.DataFrame)):
                                    stats_data.append([key.replace('_', ' ').title(), str(value)])
                        stats_data.append(['', ''])
                    
                    stats_df = pd.DataFrame(stats_data, columns=['Test Parameter', 'Result'])
                    stats_df.to_excel(writer, sheet_name='Statistical_Results', index=False)
                    ws5 = writer.sheets['Statistical_Results']
                    self.apply_professional_styling(ws5, stats_df)
                    
                    print("✓ Created statistical results sheet")
                
                # Sheet 7: Descriptive Analysis
                if 'descriptive' in self.results:
                    # Create a comprehensive descriptive analysis sheet
                    desc_data = [['DESCRIPTIVE ANALYSIS SUMMARY'], ['']]
                    
                    for analysis_name, analysis_data in self.results['descriptive'].items():
                        desc_data.append([f'=== {analysis_name.upper().replace("_", " ")} ==='])
                        desc_data.append([''])
                        
                        if isinstance(analysis_data, pd.DataFrame):
                            # Add headers
                            header_row = [''] + list(analysis_data.columns)
                            desc_data.append(header_row)
                            
                            # Add data
                            for idx, row in analysis_data.iterrows():
                                data_row = [str(idx)] + [str(val) for val in row.values]
                                desc_data.append(data_row)
                        
                        desc_data.append([''])
                    
                    # Pad columns to ensure consistent width
                    max_cols = max(len(row) for row in desc_data)
                    for row in desc_data:
                        while len(row) < max_cols:
                            row.append('')
                    
                    desc_df = pd.DataFrame(desc_data)
                    desc_df.to_excel(writer, sheet_name='Descriptive_Analysis', index=False, header=False)
                    ws6 = writer.sheets['Descriptive_Analysis']
                    self.apply_report_styling(ws6)
                    
                    print("✓ Created descriptive analysis sheet")
            
            print(f"\n🎉 Professional Excel file created successfully!")
            print(f"📍 Full path: {full_path}")
            
        except Exception as e:
            print(f"❌ Error creating Excel file: {e}")
    
    def apply_professional_styling(self, ws, df):
        """Apply professional styling to worksheet"""
        # Header styling
        header_fill = PatternFill(start_color='2E75B6', end_color='2E75B6', fill_type='solid')
        header_font = Font(name='Calibri', size=12, bold=True, color='FFFFFF')
        
        # Apply header styling
        for col in range(1, len(df.columns) + 1):
            cell = ws.cell(row=1, column=col)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # Auto-adjust column widths
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Apply borders to all cells
        for row in ws.iter_rows():
            for cell in row:
                cell.border = Border(
                    left=Side(style='thin'),
                    right=Side(style='thin'),
                    top=Side(style='thin'),
                    bottom=Side(style='thin')
                )
    
    def apply_data_styling(self, ws, df):
        """Apply styling to data worksheets"""
        # Header styling
        header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
        header_font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
        
        # Apply header styling
        for col in range(1, len(df.columns) + 1):
            cell = ws.cell(row=1, column=col)
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')
        
        # Auto-adjust column widths
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 30)
            ws.column_dimensions[column_letter].width = adjusted_width
    
    def apply_report_styling(self, ws):
        """Apply special styling to report worksheets"""
        # Apply alternating row colors for readability
        light_fill = PatternFill(start_color='F2F2F2', end_color='F2F2F2', fill_type='solid')
        white_fill = PatternFill(start_color='FFFFFF', end_color='FFFFFF', fill_type='solid')
        
        for row_idx, row in enumerate(ws.iter_rows(), 1):
            for cell in row:
                if row_idx % 2 == 0:
                    cell.fill = light_fill
                else:
                    cell.fill = white_fill
                
                cell.font = Font(name='Calibri', size=10)
                cell.border = Border(
                    left=Side(style='thin'),
                    right=Side(style='thin'),
                    top=Side(style='thin'),
                    bottom=Side(style='thin')
                )
    
    def get_overall_conclusion(self):
        """Generate overall conclusion based on statistical results"""
        if 'statistical' not in self.results:
            return "Inconclusive - No statistical tests performed"
        
        significant_count = 0
        total_tests = 0
        
        for test_name, test_data in self.results['statistical'].items():
            if isinstance(test_data, dict) and 'significant' in test_data:
                total_tests += 1
                if test_data['significant']:
                    significant_count += 1
        
        if total_tests == 0:
            return "Inconclusive - No valid statistical tests"
        
        significance_ratio = significant_count / total_tests
        
        if significance_ratio >= 0.5:
            return "Strong evidence for predator perception"
        elif significance_ratio >= 0.25:
            return "Moderate evidence for predator perception"
        else:
            return "Weak or no evidence for predator perception"
    
    def create_visualizations(self):
        """Create enhanced visualizations"""
        print("\n" + "="*60)
        print("CREATING ENHANCED VISUALIZATIONS")
        print("="*60)
        
        # Create figures directory
        figures_dir = os.path.join(self.output_dir, 'figures')
        if not os.path.exists(figures_dir):
            os.makedirs(figures_dir)
        
        # Set up the plotting parameters
        plt.style.use('seaborn-v0_8-whitegrid')
        fig_size = (15, 10)
        
        # 1. Risk Behavior by Context
        if all(col in self.df1.columns for col in ['habit', 'risk_category']):
            plt.figure(figsize=fig_size)
            
            risk_by_context = pd.crosstab(self.df1['habit'], self.df1['risk_category'], normalize='index') * 100
            
            ax = risk_by_context.plot(kind='bar', stacked=True, color=['#FF6B6B', '#4ECDC4'])
            plt.title('Risk-Taking Behavior by Context', fontsize=16, fontweight='bold', pad=20)
            plt.xlabel('Behavioral Context', fontsize=12)
            plt.ylabel('Percentage (%)', fontsize=12)
            plt.legend(title='Risk Behavior', bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            
            plt.savefig(os.path.join(figures_dir, 'risk_behavior_by_context.png'), dpi=300, bbox_inches='tight')
            plt.close()
            print("✓ Created risk behavior by context plot")
        
        # 2. Vigilance Comparison
        if all(col in self.df1.columns for col in ['habit', 'bat_landing_to_food']):
            plt.figure(figsize=fig_size)
            
            # Filter out extreme outliers for better visualization
            vigilance_data = self.df1[self.df1['bat_landing_to_food'] < self.df1['bat_landing_to_food'].quantile(0.95)]
            
            # Create boxplot
            sns.boxplot(x='habit', y='bat_landing_to_food', data=vigilance_data)
            plt.title('Vigilance (Time to Approach Food) by Context', fontsize=16, fontweight='bold', pad=20)
            plt.xlabel('Behavioral Context', fontsize=12)
            plt.ylabel('Time to Approach Food (seconds)', fontsize=12)
            plt.xticks(rotation=45, ha='right')
            plt.tight_layout()
            
            plt.savefig(os.path.join(figures_dir, 'vigilance_by_context.png'), dpi=300, bbox_inches='tight')
            plt.close()
            print("✓ Created vigilance comparison plot")
        
        # 3. Success Rate Analysis
        if all(col in self.df1.columns for col in ['habit', 'reward']):
            plt.figure(figsize=fig_size)
            
            success_rates = self.df1.groupby('habit')['reward'].mean().sort_values(ascending=False)
            
            colors = plt.cm.viridis(np.linspace(0, 1, len(success_rates)))
            bars = plt.bar(range(len(success_rates)), success_rates.values, color=colors)
            
            plt.title('Success Rate by Behavioral Context', fontsize=16, fontweight='bold', pad=20)
            plt.xlabel('Behavioral Context', fontsize=12)
            plt.ylabel('Success Rate', fontsize=12)
            plt.xticks(range(len(success_rates)), success_rates.index, rotation=45, ha='right')
            plt.ylim(0, 1)
            
            # Add value labels on bars
            for i, bar in enumerate(bars):
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                        f'{height:.3f}', ha='center', va='bottom')
            
            plt.tight_layout()
            plt.savefig(os.path.join(figures_dir, 'success_rate_analysis.png'), dpi=300, bbox_inches='tight')
            plt.close()
            print("✓ Created success rate analysis plot")
        
        # 4. Correlation Heatmap
        numeric_cols = self.df1.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 1:
            plt.figure(figsize=(12, 10))
            
            # Calculate correlation matrix
            corr_matrix = self.df1[numeric_cols].corr()
            
            # Create heatmap
            mask = np.triu(np.ones_like(corr_matrix, dtype=bool))
            sns.heatmap(corr_matrix, mask=mask, annot=True, cmap='RdBu_r', center=0,
                       square=True, linewidths=0.5, cbar_kws={"shrink": 0.8})
            
            plt.title('Correlation Matrix - Behavioral Variables', fontsize=16, fontweight='bold', pad=20)
            plt.tight_layout()
            plt.savefig(os.path.join(figures_dir, 'correlation_heatmap.png'), dpi=300, bbox_inches='tight')
            plt.close()
            print("✓ Created correlation heatmap")
        
        # 5. Temporal Patterns
        if 'seconds_after_rat_arrival' in self.df1.columns:
            plt.figure(figsize=fig_size)
            
            timing_data = self.df1['seconds_after_rat_arrival'].dropna()
            
            # Create histogram with density curve
            plt.hist(timing_data, bins=30, density=True, alpha=0.7, color='skyblue', edgecolor='black')
            
            # Add density curve
            from scipy.stats import gaussian_kde
            kde = gaussian_kde(timing_data)
            x_range = np.linspace(timing_data.min(), timing_data.max(), 1000)
            plt.plot(x_range, kde(x_range), 'r-', linewidth=2)
            
            plt.title('Distribution of Bat Landing Times After Rat Arrival', fontsize=16, fontweight='bold', pad=20)
            plt.xlabel('Seconds After Rat Arrival', fontsize=12)
            plt.ylabel('Density', fontsize=12)
            
            # Add mean and median lines
            mean_time = timing_data.mean()
            median_time = timing_data.median()
            plt.axvline(mean_time, color='green', linestyle='--', label=f'Mean: {mean_time:.1f}s')
            plt.axvline(median_time, color='orange', linestyle='--', label=f'Median: {median_time:.1f}s')
            plt.legend()
            
            plt.tight_layout()
            plt.savefig(os.path.join(figures_dir, 'timing_distribution.png'), dpi=300, bbox_inches='tight')
            plt.close()
            print("✓ Created timing distribution plot")
        
        print(f"\n🎨 All visualizations saved to: {figures_dir}")
    
    def generate_comprehensive_report(self):
        """Generate comprehensive analysis report"""
        print("\n" + "="*60)
        print("GENERATING COMPREHENSIVE ANALYSIS REPORT")
        print("="*60)
        
        print("\n🔬 HIT140 ASSESSMENT 2 - COMPREHENSIVE ANALYSIS REPORT")
        print("=" * 65)
        print("Investigation A: Do Egyptian Fruit Bats perceive Black Rats as predators?")
        print("=" * 65)
        
        print(f"\n📊 DATASET OVERVIEW:")
        print(f"   • Dataset 1 (Individual Bat Landings): {self.df1.shape[0]} observations")
        print(f"   • Dataset 2 (30-minute Observation Periods): {self.df2.shape[0]} observations")
        
        print(f"\n🔍 METHODOLOGICAL APPROACH:")
        print("   • Enhanced data cleaning with multiple rat presence indicators")
        print("   • Context-based behavioral analysis (rat vs non-rat situations)")
        print("   • Multiple statistical tests (Chi-square, Mann-Whitney U, ANOVA)")
        print("   • Cross-dataset analysis for comprehensive insights")
        print("   • Professional data visualization and reporting")
        
        print(f"\n📈 KEY FINDINGS:")
        
        # Report statistical findings
        if 'statistical' in self.results:
            significant_tests = []
            non_significant_tests = []
            
            for test_name, test_data in self.results['statistical'].items():
                if isinstance(test_data, dict) and 'significant' in test_data:
                    if test_data['significant']:
                        significant_tests.append(test_name)
                    else:
                        non_significant_tests.append(test_name)
            
            if significant_tests:
                print(f"   ✅ SIGNIFICANT FINDINGS ({len(significant_tests)} tests):")
                for test in significant_tests:
                    print(f"      • {test.replace('_', ' ').title()}")
            
            if non_significant_tests:
                print(f"   ❌ NON-SIGNIFICANT FINDINGS ({len(non_significant_tests)} tests):")
                for test in non_significant_tests:
                    print(f"      • {test.replace('_', ' ').title()}")
        
        # Report key insights
        print(f"\n💡 KEY INSIGHTS:")
        
        # Insight 1: Risk behavior
        if 'risk_context_test' in self.results.get('statistical', {}):
            test_data = self.results['statistical']['risk_context_test']
            if test_data['significant']:
                print("   • Bats show DIFFERENT risk-taking behavior in rat contexts")
            else:
                print("   • No significant difference in risk-taking behavior between contexts")
        
        # Insight 2: Vigilance behavior
        if 'vigilance_context_test' in self.results.get('statistical', {}):
            test_data = self.results['statistical']['vigilance_context_test']
            if test_data['significant']:
                direction = "HIGHER" if test_data['rat_mean'] > test_data['non_rat_mean'] else "LOWER"
                print(f"   • Bats show {direction} vigilance in rat contexts")
            else:
                print("   • No significant difference in vigilance between contexts")
        
        # Insight 3: Cross-dataset findings
        if 'cross_dataset_test' in self.results.get('statistical', {}):
            test_data = self.results['statistical']['cross_dataset_test']
            if test_data['significant']:
                direction = "HIGHER" if test_data['active_mean'] > test_data['inactive_mean'] else "LOWER"
                print(f"   • Bat activity is {direction} during periods with rat activity")
            else:
                print("   • No significant difference in bat activity based on rat presence")
        
        print(f"\n📋 STUDY LIMITATIONS:")
        print("   • Observational data - correlation does not imply causation")
        print("   • Potential confounding variables not measured")
        print("   • Data quality issues in original datasets")
        print("   • Limited control group for some analyses")
        
        print(f"\n🎯 CONCLUSION:")
        conclusion = self.get_overall_conclusion()
        print(f"   {conclusion}")
        
        print(f"\n📁 FILES GENERATED:")
        print(f"   • Excel report: {os.path.join(self.output_dir, 'HIT140_Professional_Analysis_Results.xlsx')}")
        print(f"   • Visualizations: {os.path.join(self.output_dir, 'figures')} directory")
        
        print("\n" + "="*65)
        print("ANALYSIS COMPLETE - READY FOR PRESENTATION!")
        print("="*65)

def main():
    """Main function to run the enhanced analysis"""
    
    # Dataset paths - UPDATE THESE WITH YOUR ACTUAL PATHS
    dataset1_path = r"C:\Users\Shivansh\Downloads\dataset1.csv"
    dataset2_path = r"C:\Users\Shivansh\Downloads\dataset2.csv"
    
    # Initialize enhanced analysis
    print("🦇 HIT140 ASSESSMENT 2: ENHANCED BAT VS RAT ANALYSIS")
    print("=" * 60)
    print("Investigation A: Do bats perceive rats as predators?")
    print("=" * 60)
    
    # Create analysis object
    analysis = ImprovedBatRatAnalysis(dataset1_path, dataset2_path)
    
    # Step 1: Load and clean data
    if not analysis.load_and_clean_data():
        print("❌ Failed to load data. Please check file paths.")
        return
    
    # Step 2: Comprehensive descriptive analysis
    analysis.comprehensive_descriptive_analysis()
    
    # Step 3: Advanced statistical analysis
    analysis.advanced_statistical_analysis()
    
    # Step 4: Create professional Excel file
    analysis.create_professional_excel()
    
    # Step 5: Create enhanced visualizations
    analysis.create_visualizations()
    
    # Step 6: Generate comprehensive report
    analysis.generate_comprehensive_report()
    
    print(f"\n🎉 ENHANCED ANALYSIS COMPLETE!")
    print(f"📁 Files created in: {analysis.output_dir}")
    print(f"📊 Excel report: HIT140_Professional_Analysis_Results.xlsx")
    print(f"🖼️  Visualizations: figures/ directory")
    print(f"\n✅ Ready for high-quality presentation preparation!")

if __name__ == "__main__":
    main()